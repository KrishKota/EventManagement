package com.sai.eventmanagement.controllers.exceptions;

public class AlreadyCheckedInException extends RuntimeException {

}
